list(
  rd_family_title = list(
    diagnostics = "Model diagnostics",
    examples = "Example models",
    formulas = "Model formula construction",
    fitting = "Model fitting",
    output = "Model outputs",
    plotting = "Drawing plots",
    prediction = "Obtaining predictions"
  )
)
